package mr

import (
	"encoding/json"
	"fmt"
	"hash/fnv"
	"io/ioutil"
	"log"
	"net/rpc"
	"os"
	"sort"
	"strconv"
)

//
// Map functions return a slice of KeyValue.
//
type KeyValue struct {
	Key   string
	Value string
}

//
// use ihash(key) % NReduce to choose the reduce
// task number for each KeyValue emitted by Map.
//
func ihash(key string) int {
	h := fnv.New32a()
	h.Write([]byte(key))
	return int(h.Sum32() & 0x7fffffff)
}

//
// main/mrworker.go calls this function.
//
func Worker(mapf func(string, string) []KeyValue,
	reducef func(string, []string) string) {

	// Your worker implementation here.

	// uncomment to send the Example RPC to the master.
	// CallExample()

	// 获得文件名
	taskInfo := CallNewMapTask()
	//读取文件内容
	contents, err := ioutil.ReadFile(taskInfo.Filename)

	if err != nil {
		log.Fatal(err)
	}

	// fmt.Printf("File contents: %s", contents)
	kva := mapf(taskInfo.Filename, string(contents))

	// 将产生的<key, value>按照key值分到不同的partition
	enc := make([]*json.Encoder, taskInfo.NReduce)
	for i := 0; i < taskInfo.NReduce; i++ {
		filename := "mr-out-" + strconv.Itoa(taskInfo.Id) + "-" + strconv.Itoa(i)
		writer, _ := os.OpenFile(filename, os.O_RDWR|os.O_CREATE, 0755)
		enc[i] = json.NewEncoder(writer)
	}

	// 对kva按照进行排序
	sort.Slice(kva, func(i, j int) bool {
		return kva[i].Key <= kva[j].Key
	})

	for _, kv := range kva {
		i := ihash(kv.Key) % taskInfo.NReduce
		if err != nil {
			log.Fatal(err)
		}
		enc[i].Encode(&kv)
	}
}

//
// example function to show how to make an RPC call to the master.
//
// the RPC argument and reply types are defined in rpc.go.
//
func CallExample() {

	// declare an argument structure.
	args := ExampleArgs{}

	// fill in the argument(s).
	args.X = 99

	// declare a reply structure.
	reply := ExampleReply{}

	// send the RPC request, wait for the reply.
	call("Master.Example", &args, &reply)

	// reply.Y should be 100.
	fmt.Printf("reply.Y %v\n", reply.Y)
}

func CallNewMapTask() NewMapTaskReply {
	args := NewMapTaskArgs{}
	reply := NewMapTaskReply{}

	call("Master.NewMapTask", &args, &reply)
	if reply.Err != nil {
		log.Fatal(reply.Err)
	}
	fmt.Printf("得到一个map任务, 文件名:%s  任务编号:%d  nReduce:%d\n", reply.Filename, reply.Id, reply.NReduce)
	return reply
}

//
// send an RPC request to the master, wait for the response.
// usually returns true.
// returns false if something goes wrong.
//
func call(rpcname string, args interface{}, reply interface{}) bool {
	// c, err := rpc.DialHTTP("tcp", "127.0.0.1"+":1234")
	sockname := masterSock()
	c, err := rpc.DialHTTP("unix", sockname)
	if err != nil {
		log.Fatal("dialing:", err)
	}
	defer c.Close()

	err = c.Call(rpcname, args, reply)
	if err == nil {
		return true
	}

	fmt.Println(err)
	return false
}
